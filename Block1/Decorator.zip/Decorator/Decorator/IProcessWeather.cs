﻿
namespace Decorator {
    public interface IProcessWeather {
        void ProcessWeather();
    }
}
